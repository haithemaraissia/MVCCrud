CREATE TABLE Names 
(FirstName VARCHAR (20), LastName VARCHAR (20));